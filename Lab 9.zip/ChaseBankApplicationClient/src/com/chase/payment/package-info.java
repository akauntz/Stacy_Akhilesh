@javax.xml.bind.annotation.XmlSchema(namespace = "http://payment.chase.com/")
package com.chase.payment;
